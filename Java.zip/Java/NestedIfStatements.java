package Java;
class Main{
	public static void main(String[] args){
		System.out.println("Nested If Statements To Check Multiple Conditions");
		boolean isStudent = true;
		boolean isSenior = true;
		double movieTicketPrice = 9.99;

		if(isStudent){
			if(isSenior){
				System.out.println("You are a senior and you get a 20% discount");
				System.out.println("You are a student and you get a 10% discount");
				movieTicketPrice *= 0.7;
			}
			else{
				System.out.println("You are a student and you get a 10% discount");
				movieTicketPrice *= 0.9;
			}
		}
		else if(isSenior){
			System.out.println("You are a senior and you get a 20% discount");
			movieTicketPrice *= 0.8;

		}
		else{
			movieTicketPrice *= 1;
		}
		System.out.printf("The movie ticket price is $%.2f\n", movieTicketPrice);
	}
}
