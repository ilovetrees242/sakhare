import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		System.out.println("If statements - position based on age entered");
		//if statement = performs a block of code if its condition is true

		Scanner scanner = new Scanner(System.in);
		int age;

		System.out.print("Enter your age: ");
		age = scanner.nextInt();

		if(age == 0){
			System.out.println("You are a newborn!");
		}
		else if(age >= 100){
			System.out.println("You are very old!");
		}
		else if(age >= 65){
			System.out.println("You are a senior!");
		}
		else if(age >= 18){
			System.out.println("You are an adult!");
		}
		else if(age >= 13){
			System.out.println("You are a teenager!");
		}
		else if(age >= 8){
			System.out.println("You are a kid!");
		}
		else if(age >= 5){
			System.out.println("You are a toddler!");
		}

		scanner.close();
	}
}
