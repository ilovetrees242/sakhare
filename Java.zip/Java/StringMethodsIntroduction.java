package Java;
class Main{
	public static void main(String[] args){
		System.out.println("Various Methods for strings: ");
		System.out.println("length() method" + " now here we will create a variable called name.\n");
		String name = "Java Developer";

		//always store length in integer variables
		int length = name.length();

		System.out.println("The length of variable name is " + length);
		System.out.println("Variable name was " + name + "\n");

		System.out.println("The charAt([index]) method to find the char stored in a position in a string");
		System.out.println("Storing the first letter and the last letter of the variable name(always starts from 0)\n");
		char ch1 = name.charAt(0);
		char ch2 = name.charAt(13);
		System.out.println("The first and last letter of " + name + " is " + ch1 + " and " + ch2 + "\n");

		System.out.println("The indexOf() method fines the index of a specific character. Lets say we want to find the index of e");

		int index = name.indexOf("e");

 		System.out.println("The index of e is " + index + "\n");

		System.out.println("The toUpperCase() method transforms all characters in a string to uppercase: ");

		String upperCase = name.toUpperCase();
		
		System.out.println("The uppercase version of " + name + " is " + upperCase + ".\n");

		System.out.println("Now to make all characters lowercase use toLowerCase() method");

		String lowerCase = name.toLowerCase();

		System.out.println("The lowercase version of " + name + " is " + lowerCase + ".\n");

		System.out.println("You can remove unnecessary spaces using .trim()\n");

		String spaceName = "            " + name + "               ";

		System.out.println("Without trim(): " + spaceName);
		System.out.println("With trim(): " + spaceName.trim());

		System.out.println("\n Replace characters in a string with another character using .replace()");

		String replacedVersion = name.replace("a", "e");
		System.out.println("Using replace() to replace a with e: " + replacedVersion);

		System.out.println();


	}
}
