import java.util.Scanner;
import java.util.Random;

class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		
 		System.out.print("Enter your comparative 1: ");
		String a = scanner.nextLine();
 		System.out.print("Enter your comparative 2: ");
		String b = scanner.nextLine();
		System.out.print("How many times would you like to repeat the process?(max 1000): ");
 		int repeat = scanner.nextInt();

		int C = 0;
		int B = 0;

		if(repeat >= 1000){
			System.out.println("Number too large. Program will exit.");
		}
		else if(a.isEmpty()){
			System.out.println("No comparitive a given!");
		}
		else if(b.isEmpty()){
			System.out.println("No comparitive b given!");
		}
		else{
			for(int i = 0; i < repeat; i++){
				int number;

				number = random.nextInt(1, 3);

				if(number == 1){
					System.out.println(a);
					B++;
				}
				else if(number == 2){
					System.out.println(b);
					C++;
				}
			}
			if(B > C){
				System.out.println("\n" + a + " wins!");
			}
			else if(C > B){
				System.out.println("\n" + b + " wins!");
			}
			else if(C == B){
				System.out.println(a + " and " + b + " tied!");
			}
		}
		scanner.close();
	}
}
