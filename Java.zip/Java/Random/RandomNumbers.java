import java.util.Random;

class Main{
	public static void main(String[] args){
		
		Random random = new Random();

		int N;
		
		N = random.nextInt(1, 11);

		System.out.println(N);
	}
}
