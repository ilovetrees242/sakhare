class Main{
	public static void main(String[] args){
		System.out.println("Char Data Types.");
		// use single quotes '' instead of double quotes ""
		char Grade = 'A';
		System.out.println("In this class, 70% of the students have gotten the grade " + Grade + " in the subject maths." );
		System.out.println("Combining 3 data types in one print statement(str double int)");
		char currency = '₹';
		double cost = 59.99;
		int quantity = 5;
		System.out.println("The " + quantity + " pencils together cost " + currency + cost + ".");
	}
}
