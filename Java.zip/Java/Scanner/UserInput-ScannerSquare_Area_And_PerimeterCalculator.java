import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		System.out.println("Square area and perimeter calculator");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Choose your operation(for area enter 1 for perimeter enter 2): ");
		int operation = scanner.nextInt();
		for(int i = 0; i < 10; i++){
			if(operation >= 2){ 
				System.out.print("\033[H\033[2J");
                	        System.out.flush();
				System.out.println("Please enter either 1 or 2.");
				System.out.print("Choose your operation(for area enter 1 for perimeter enter 2): ");
		                operation = scanner.nextInt();
				if(operation == 1){
        	               		 System.out.print("Enter your side in cm: ");
        	                	 int side = scanner.nextInt();
        	               		 if(side == 1){
        	                      		int area = 10;
        	            		        System.out.println("The area of your square is: " + area + "cm²");
        	               		        }
                	       		 else{
					  	int area = side * side;
          	               		  	System.out.println("The area of your square is: " + area + "cm²");
          	     		         	}
				} 	
          	     		else if(operation == 2){
               	        		System.out.print("Enter your side in cm: ");
                       			int pside = scanner.nextInt();
                	       		 if(pside == 1){
                              	        	 int p = pside + pside + pside + pside;
                               	           	 System.out.println("The periemeter of your square is: " + p + "cm");
                       			}
                        		else{
                                	         int p = pside * 4;
                               		         System.out.println("The perimeter of your square is: " + p +"cm");
                               	        }
                       		 }
	
			}
		}
		if(1 + 1 == 3){
			
		}
		else{
			if(operation == 1){
				System.out.print("Enter your side in cm: ");
				int side = scanner.nextInt();
			if(side == 1){
				int area = 10;
				System.out.println("The area of your square is: " + area + "cm²");
			}
			int area = side * side;
			System.out.println("The area of your square is: " + area + "cm²");
			}
		else if(operation == 2){
			System.out.print("Enter your side in cm: ");
			int pside = scanner.nextInt();
			if(pside == 1){
				int p = pside + pside + pside + pside;
				System.out.println("The periemeter of your square is: " + p + "cm");
			}
			else{
				int p = pside * 4;
				System.out.println("The perimeter of your square is: " + p +"cm");
				}
			}
		}
		scanner.close();
	}
}
