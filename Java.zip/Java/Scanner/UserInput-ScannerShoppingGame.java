import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("Shopping Program");

		Scanner scanner = new Scanner(System.in);
		
		String item;
		double price;
		int quantity;
		char currency = '₹';

		System.out.print("What item would you like to buy?: ");
		item = scanner.nextLine();
		System.out.print("What is the price for each?: " + currency);
		price = scanner.nextDouble();
		System.out.print("How many would you like to buy?: ");
		quantity = scanner.nextInt();

		System.out.print("\nYou have bought " + quantity + " " + item + " and your total is: ");
		double total = price * quantity;
		System.out.print(currency);
		System.out.print(total + "\n");
		scanner.close();
	}
}
