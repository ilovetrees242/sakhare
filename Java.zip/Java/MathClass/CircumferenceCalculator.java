import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("Circumference Calculator");
		Scanner scanner = new Scanner(System.in);
		
		double radius;
		double circumference;

		System.out.print("Enter the radius of your circle: ");
		radius = scanner.nextDouble();
		
		//C = 2*pi*radius
		
		circumference = 2 * Math.PI * radius;
		System.out.println("The circumference of your circle is = " + circumference + "cm");

		scanner.close();
	}
}
