package Java;
class Main{
	public static void main(String[] args){
		System.out.println("Printf Statements.\n");
		//printf() = a methodused to format an output
		//%[flags] [width] [.precision][specifier-character
		//%s = string %d = integer %f = double %c = char %b = boolean
		
		String name = "John";
		int age = 35;
		double height = 5.3;
		char firstLetter = 'J';
		boolean isEmployed = true;

		System.out.printf("Hello %s.\n", name);
		System.out.printf("You are %d years old.\n", age);
		System.out.printf("You are %f tall.\n", height);
		System.out.printf("Your name starts with %c.\n", firstLetter);
		System.out.printf("Are you employed?: %b.\n", isEmployed);
		System.out.println("Printing multiple variables in one printf statement:\n");
		String food = "pizza";
		String type = "chicken barbeque";
		System.out.printf("You like %s with %s topping.\n", food, type);

		//.precision method for limiting decimal values

		System.out.println("\nUsing [.precision] method to limit decimal places:\n");

		double priceA = 99.99;
		double priceB = -100.50;
		double priceC = 150.25;

		System.out.printf("Price A = %.1f\n", priceA);
		System.out.printf("Price B = %.1f\n", priceB);
		System.out.printf("Price C = %.1f\n", priceC);
		System.out.printf("Testing PI = %.2f\n", Math.PI);

		System.out.println("\n[flags] methods for special outputs with numbers");

		//%[flag][number]
		// + = output a plus for positive numbers
		// , = comma separate numbers with international method
		// ( = encloses negative numbers in ()
		// [SPACE] = leave space if positive, display a minus if negative

		System.out.println("What happens with all cases:\n");
		System.out.println("+ flag: ");

		System.out.printf("%+.2f\n", priceA);
		System.out.printf("%+.2f\n", priceB);
		System.out.printf("%+.2f\n", priceC);
		
		priceA = 9900000.99;
		priceB = -100000.50;
		priceC = 15000000.25;

		System.out.println("\n, flag: ");

		System.out.printf("%,.2f\n", priceA);
		System.out.printf("%,.2f\n", priceB);
		System.out.printf("%,.2f\n", priceC);
	
		priceA = 99.99;
		priceB = -100.50;
		priceC = 150.25;

		System.out.println("\n( flag: ");

		System.out.printf("%(.2f\n", priceA);
		System.out.printf("%(.2f\n", priceB);
		System.out.printf("%(.2f\n", priceC);

		System.out.printf("\n[SPACE] flag:\n");

		System.out.printf("% .2f\n", priceA);
		System.out.printf("% .2f\n", priceB);
		System.out.printf("% .2f\n\n", priceC);

		//width
		//0 = padd with 0 to left (%0[NUMBEROF0TOPADWITH][specifierCharacter])
		//Positive number = padd with spaces instead of 0 (%[Digit][SpecifierCharacter])
		//Negative number = padd with spaces added to right

		int id1 = 1;
		int id2 = 23;
		int id3 = 456;
		int id4 = 7890;

		//0 padding
		System.out.println("Padding with 0\n");
		System.out.printf("%04d\n", id1);
		System.out.printf("%04d\n", id2);
		System.out.printf("%04d\n", id3);
		System.out.printf("%04d\n\n", id4);

		//Postive number padding (Only Spaces)
		System.out.println("Padding with positive numbers\n");
		System.out.printf("%4d\n", id1);
		System.out.printf("%4d\n", id2);
		System.out.printf("%4d\n", id3);
		System.out.printf("%4d\n\n", id4);

		//Negative number padding (Adds Spaces to the right side only.)
		System.out.println("Padding with negative numbers\n");
		System.out.printf("%-4d\n", id1);
		System.out.printf("%-4d\n", id2);
		System.out.printf("%-4d\n", id3);
		System.out.printf("%-4d\n", id4);



	}
}
