import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your number below 255: ");
		int decimal = scanner.nextInt();
		int remainder;
		int quotient = decimal;
		String binary = "";
		for(int i = 8; i > 0; i--){
			remainder = quotient % 2;
			if(remainder == 0){
				quotient /= 2;
				binary += 0;
			}
			if(remainder == 1){
				quotient /= 2;
				binary += 1;
			}
		}
		System.out.print(binary.charAt(7));
		System.out.print(binary.charAt(6));
		System.out.print(binary.charAt(5));
		System.out.print(binary.charAt(4));
		System.out.print(binary.charAt(3));
		System.out.print(binary.charAt(2));
		System.out.print(binary.charAt(1));
		System.out.print(binary.charAt(0) + "\n");
		scanner.close();
	}
}
