class Main{
	public static void main(String[] args){
		System.out.println("Arithmetic Operators\n");
		System.out.println("x = 10");
		System.out.println(" y = 5\n");

		//Arithmetic Operators
		
		int x = 10;
		int y = 5;
		int z;
		
		z = x + y;	
		System.out.println("Addition(+): "+ z);
		z = x - y;	
		System.out.println("Subtraction(-): "+ z);
		z = x * y;	
		System.out.println("Multiplication(*): "+ z);
		z = x / y;	
		System.out.println("Divsion(/): "+ z);
		z = x % y;	
		System.out.println("Modulous(%): "+ z);

		// Augmented Arithmetic Operators
		
		System.out.println("\nAugmented Arithemetic Operators\n");

		int a = 20;
		int b = 2;

		a += b;
		System.out.println("a = 20, b = 2. a is being reassigned(case: a +=b)\n");
		System.out.println("This basically permforms one operation on two variables and reassigns the same value again to one of the variables(a in this case):\n");
		System.out.println("Addition(+=): " + a);
		a = 20;
		a -= b;
		System.out.println("Subtraction(-=): " + a);
		a = 20;
		a *= b;
		System.out.println("Multiplication(*=): " + a);
		a = 20;
		a /= b;
		System.out.println("Division(/=): " + a);
		a = 20;
		a %= b;
		System.out.println("Modulous(%=): " + a);

		// Increment and Decrement Operators
		System.out.println("\nIncrement and Decrement Operators(increments by 1)\n");
		
		int e = 1;
		System.out.println("e = 1, e++ will increment the value by 1:");
		e++;
		System.out.println(e + "\n");
		e = 1;
		System.out.println("This will perform e-- to decrement value by 1:");
		e--;
		System.out.println(e);
	}
}
