class Main{
	public static void main(String[] args){
		int testnum = 0;
		for(int i = 1; i < 101; i++){
			while(testnum < i){
				testnum++;
				if(i % testnum == 0){
					System.out.print(i + " ");
				}
			}
			testnum = 0;
		}
	}
}

