import java.util.Scanner;
class Main{
	public static void main(String[] args){
		System.out.println("Table of any number from 1 to 2.1 billion");
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter your number: ");
		int number = scanner.nextInt();
		if(number < 2147483647){
			int loopNumber = 0;
			for(int i = 0; i < 10; i++){
				loopNumber++;
				System.out.println(number + " times " + loopNumber + " = " + number * loopNumber);
			}
		}
		scanner.close();
	}
}
