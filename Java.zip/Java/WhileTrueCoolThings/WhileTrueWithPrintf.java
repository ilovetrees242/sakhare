class Main{
	public static void main(String[] args){
		int i = 1;
		while(true){
			System.out.printf("%1d\n", i);
			System.out.printf("%2d\n", i);
			System.out.printf("%3d\n", i);
			System.out.printf("%4d\n", i);
			System.out.printf("%5d\n", i);
			System.out.printf("%6d\n", i);
			System.out.printf("%7d\n", i);
			System.out.printf("%8d\n", i);
			System.out.printf("%9d\n", i);
			System.out.printf("%10d\n", i);
			System.out.printf("%11d\n", i);
			System.out.printf("%10d\n", i);
			System.out.printf("%9d\n", i);
			System.out.printf("%8d\n", i);
			System.out.printf("%7d\n", i);
			System.out.printf("%6d\n", i);
			System.out.printf("%5d\n", i);
			System.out.printf("%4d\n", i);
			System.out.printf("%3d\n", i);
			System.out.printf("%2d\n", i);
			System.out.printf("%1d\n", i);
		}
	} 
}
