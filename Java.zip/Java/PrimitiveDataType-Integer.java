class Main{
	public static void main(String[] args){
	System.out.println("Integer Data Type");
	int age = 25;	
	System.out.println("You are " + age + " years old.");
	int year = 2025;	
	System.out.println("The year is " + year + ".");
	}
}
