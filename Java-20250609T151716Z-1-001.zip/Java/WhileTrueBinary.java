import java.util.Random;
class Main{
	public static void main(String[] args){
		Random random = new Random();
		while(true){
			int binaryRandom = random.nextInt(0, 2);
			System.out.print(binaryRandom + " ");
		}
	}
}
