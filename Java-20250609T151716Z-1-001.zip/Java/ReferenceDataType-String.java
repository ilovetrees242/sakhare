class Main{
	public static void main(String[] args){
		System.out.println("String Data Type");
		String firstName = "John";
		String lastName = "Doe";
		System.out.println("Your name is: " + firstName + " " + lastName);
	}
}
