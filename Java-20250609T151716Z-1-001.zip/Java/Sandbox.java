class Main{
	public static void main(String[] args){
		int age = 0;

		if(age < 0){
			System.out.println("bro is not born");
		}
	}
}
