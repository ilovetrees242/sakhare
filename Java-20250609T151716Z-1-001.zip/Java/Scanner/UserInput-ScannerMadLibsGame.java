import java.util.Scanner;

class Main{
	public static void main(String[] args){
		
		Scanner scanner = new Scanner(System.in);

		System.out.println("Mad Libs Game");

		String adjective1;
		String noun1;
		String adjective2;
		String verb1;
		String adjective3;

		System.out.print("Enter your adjective(description): ");
		adjective1 = scanner.nextLine();
		System.out.print("Enter your noun(person, place, object): ");
		noun1 = scanner.nextLine();
		System.out.print("Enter your adjective(description): ");
		adjective2 = scanner.nextLine();
		System.out.print("Enter your verb(action)(should end with ing): ");
		verb1 = scanner.nextLine();
		System.out.print("Enter your adjective(description): ");
		adjective3 = scanner.nextLine();

		System.out.println("\nOne day i was at a " + adjective1 + " mall.");
		System.out.println("I saw a " + noun1 + " with a " + adjective2 + " appearance.");
		System.out.println("The lady was " + adjective1 + " and was showing me some " + adjective2 + " clothes.");
		System.out.println("I am" + verb1 + " to get food because I am hungry.");
		System.out.println("The day is very " + adjective3 + " and I am " + verb1 + " towards the next destination.");
		scanner.close();
	}
}
