class Main{
	public static void main(String[] args){
		System.out.println("Usage of math class for advanced maths\n");
		System.out.println("Pi = " + Math.PI);
		System.out.println("Euler's number = " + Math.E);
		System.out.println("\nUseful Math Class Options:\n");

		//Raising to power of(arg 1 = target number arg 2 = raising to power of)

		System.out.println("2 to power of 4(Math.pow(2, 4)) = " + Math.pow(2, 4));

		//Absolute value of specific number (distance from 0)

		System.out.println("Absolute value of -5(Math.abs(-5)) = " + Math.abs(-5));

		//Square root = inverse operation of square for finding the original base number, 16 sqrt = 4, 64 = 8

		System.out.println("Square root of the number 18(Math.sqrt(25)) = " + Math.sqrt(25));

		//Rounding = rounding off a number to the nearest whole integer 3.6 = 4 , 3.3 = 3
		
		System.out.println("Rounding off 3.59 to the nearest whole integer(Math.round(3.59)) = " + Math.round(3.59));
		System.out.println("Math.round() for 3.46 will be = " + Math.round(3.46));

		//Rounding with ceiling = rounds off a number to the highest whole integer

		System.out.println("Rounding off 3.19 to the highest whole integer using Math.ceil(3.19) = " + Math.ceil(3.19));

		//Rounding with floor = rounds off a number to the lowest whole integer in range

		System.out.println("Rounding off 3.95 to the lowest whole integer using Math.floor(3.95) = " + Math.floor(3.95) );
		//Minimum and maximum = finds the minimum or maximum value between two values
		
		//Maximum:

		System.out.println("Maximum value between 0 and 50(Math.max(0, 50)) = " + Math.max(0, 50));

		//Minimum:

		System.out.println("Minimum value between 15 and 25(Math.min(15, 25)) = " + Math.min(15, 25));

		System.out.println("\nSummary\n");

		System.out.println("Constants: ");
		System.out.println("Math.PI");
		System.out.println("Math.E\n");
		
		System.out.println("Non constants:\n");

		System.out.println("Math.pow(arg1, arg2)");
		System.out.println("Math.abs(arg1)");
		System.out.println("Math.sqrt(arg1)");
		System.out.println("Math.round(arg1)");
		System.out.println("Math.ceil(arg1)");
		System.out.println("Math.floor(arg1)");
		System.out.println("Math.max(arg1, arg2)");
		System.out.println("Math.min(arg1, arg2)");

	}
}
