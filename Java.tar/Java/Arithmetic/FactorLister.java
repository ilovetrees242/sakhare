import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your number(factors will be listed): ");
        int userInt = scanner.nextInt();
        int i = 0;
        while(i < userInt){
            i++;
            if(userInt % i == 0){
                if(i == userInt){
                    System.out.print(userInt + "\n");
                }
                else{
                    System.out.print(i + ", ");
                }
            }
        }
        scanner.close();
    }
}
