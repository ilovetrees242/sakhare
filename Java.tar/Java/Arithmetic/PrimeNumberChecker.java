import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your number to see if its prime number or not: ");
		int primeNumber = scanner.nextInt();
		int i = 0;
		while(i < primeNumber){
			i++;
			if(primeNumber % i > 0 && i == 2){
				System.out.println("Number is a prime number!");
				i = primeNumber + 1;
			}
			else if(primeNumber % i == 0 && i > 2){
				System.out.println("Number is not a prime number!");
				i = primeNumber + 1;
			}
			else if(primeNumber == 2 || primeNumber == 1){
				System.out.println("Number is a prime number!");
			}
		}
		scanner.close();
	}
}
