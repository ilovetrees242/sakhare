class Main{
	public static void main(String[] args){
		System.out.println("Boolean Data Types.");
		boolean isOnline = true;
		boolean isNight = false;
		System.out.println("Am I online?: " + isOnline);
		System.out.println("Is it night?: " + isNight);
	}	
}
