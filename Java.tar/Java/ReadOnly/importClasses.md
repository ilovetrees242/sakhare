//scanner class(user input)
import java.util.Scanner;
//random class(random number generator)
import java.util.Random;
