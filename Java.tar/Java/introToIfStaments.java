class main{
	public static void main(String[] args){
		System.out.println("If Statements - Introduction");

		//if statements checks for a condition and performs the code given inside the block.

		int a = 10;

		System.out.println("using if statements to check if numbers are even or odd");
		System.out.println("a = 10");

		//checks if a is even by dividing it by 2 and checking if remainder is 0 or not

		if(a % 2 == 0){
			System.out.println("a is an even number!");
		}
		//now we reassign a to another value which is odd
		System.out.println("a is reassigned to 21.");
		a = 21;
		//checking it again

		if(a % 2 == 0){
			System.out.println("a is an even number!");
		}
		else{
			System.out.println("a in an odd number!");
		}
	}
}
