import java.util.Scanner;
import java.util.Random;

class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		int OTP;
		OTP = random.nextInt(100000, 999999);
		System.out.println("Your OTP is: " + OTP);
		System.out.println("Please enter your OTP: ");
		int oneTime = scanner.nextInt();
		if(oneTime == OTP){
			System.out.println("You have successfully entered your OTP.");
		}
		else{
			System.out.println("Wrong OTP. Program will exit with code 0.");
		}
		scanner.close();
	}
}

