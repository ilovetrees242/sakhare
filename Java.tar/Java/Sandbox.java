package Java;

import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your number below 255: ");
		int decimal = scanner.nextInt();
		int remainder;
		int quotient = decimal;
		String binary = "";
		for(int i = 8; i > 0; i--){
			remainder = quotient % 2;
			if(remainder == 0){
				quotient /= 2;
				binary += 0;
			}
			if(remainder == 1){
				quotient /= 2;
				binary += 1;
			}
		}
		for(int j = 7; j > 0; j--){
			System.out.print(binary.charAt(j));
		}
		scanner.close();
	}
}
