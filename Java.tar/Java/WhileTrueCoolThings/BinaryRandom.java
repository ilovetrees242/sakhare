import java.util.Random;
import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Random random = new Random();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Would you like the numbers with spaces or no spaces?(1 = spaces 2 = no spaces): ");
		int userChoice = scanner.nextInt();
		int binaryDigit;
		if(userChoice == 1){
			while(true){
				binaryDigit = random.nextInt(0, 2);
				System.out.print(binaryDigit);
			}
		}
		else if(userChoice == 2){
			while(true){
				binaryDigit = random.nextInt(0, 2);
				System.out.print(binaryDigit + " ");
			}
		}
		else{
			System.out.println("Wrong choice!");
		}
		scanner.close();
	}
}
