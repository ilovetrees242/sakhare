package Java;
class Main{
	public static void main(String[] args){
		System.out.println("Double data types.");
		double price = 99.99;	
		System.out.println("The cost of the mango is " + price + ".");
		System.out.println("Following happens when you assign an int value to a double data type:");
		double voltage = 5;	
		System.out.println("The voltage is around " + voltage + "V.");
	}
}
