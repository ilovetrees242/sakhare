import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("Using math class to for Hypotenuse");
		//Formula: C = sqrt(a2 + b2)
		Scanner scanner = new Scanner(System.in);

		double a;
		double b;
		double c;
		
		System.out.print("Enter the side A: ");
		a = scanner.nextDouble();
		System.out.print("Enter the side B: ");	
		b = scanner.nextDouble();

		c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));

		System.out.println("C is = " + c + "cm");
		scanner.close();
	}
}
