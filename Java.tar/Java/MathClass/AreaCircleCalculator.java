import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("Circle Area Calculator");
		//A = pi r2
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the radius of your circle: ");
		double radius = scanner.nextDouble();
		double Area = Math.PI * Math.pow(radius, 2);
		System.out.println("The area is " + Area + "cm2");
		scanner.close();
	}
}
