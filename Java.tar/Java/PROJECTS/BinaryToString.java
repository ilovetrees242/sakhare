import java.util.Scanner;

class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Choose your encoding: (ASCII/UniCode): ");
		String Choice = scanner.nextLine();

		String Choice1 = "UniCode";
		String Choice2 = "ASCII";
		int LSB = 0;
		int Temp = 0;
		String DecimalString = "";
		char Result;
		String ResultString = "";
		int Dec = 0;
		if(Choice != Choice1 || Choice2){
			System.out.println("Incorrect choice. Exiting...");
			System.exit(1);
		}
		else if(Choic){}
		else if(Choice.equalsIgnoreCase(Choice1)){
			System.out.print("Enter the binary text(Spaces between every 16 characters): ");
			String BT = scanner.nextLine();
			String BinText = BT.trim();
			
			String BinArray[] = BinText.split(" ");
			
			for(int i = 0; i < BinArray.length; i++){
				if(BinArray[i].length() > 16){
					System.out.println("One or more strings are greater than 16 characters... exiting");
					System.exit(0);
				}
			}
			
			for(int i = 0; i < BinArray.length; i++){
				LSB = BinArray[i].length();
				for(int j = BinArray[i].length(); j > 0; j--){
					if(BinArray[i].charAt(j - 1) == '0'){
						Temp += 0 * Math.pow(2, LSB - j);			
					}
					else if(BinArray[i].charAt(j - 1) == '1'){
						Temp += 1 * Math.pow(2, LSB - j);
					}
				}
				DecimalString += Temp + " ";
				Temp = 0;
			}
			
			String DecArr[] = DecimalString.split(" ");

			for(int i = 0; i < DecArr.length; i++){
				Dec = Integer.parseInt(DecArr[i]);
				Result = (char) Dec;	
				ResultString += Character.toString(Result);
				Dec = 0;
			}
			System.out.println("\nYour text means: " + ResultString);
		}
		else if(Choice.equalsIgnoreCase(Choice2)){
			System.out.print("Enter the binary text(Spaces between every 8 characters): ");
			String BT = scanner.nextLine();
			String BinText = BT.trim();
			
			String BinArray[] = BinText.split(" ");
			for(int i = 0; i < BinArray.length; i++){
				if(BinArray[i].length() > 8){
					System.out.println("One or more strings are greater than 8 characters... exiting");
					System.exit(0);
				}
			}
			for(int i = 0; i < BinArray.length; i++){
				LSB = BinArray[i].length();

				for(int j = BinArray[i].length(); j > 0; j--){
					if(BinArray[i].charAt(j - 1) == '0'){
						Temp += 0 * Math.pow(2, LSB - j);			
					}
					else if(BinArray[i].charAt(j - 1) == '1'){
						Temp += 1 * Math.pow(2, LSB - j);
					}
				}
				DecimalString += Temp + " ";
				Temp = 0;
			}
			
			String DecArr[] = DecimalString.split(" ");
	
			for(int i = 0; i < DecArr.length; i++){
				Dec = Integer.parseInt(DecArr[i]);
				Result = (char) Dec;	
				ResultString += Character.toString(Result);
				Dec = 0;
			}
			System.out.println("\nYour text means: " + ResultString);
		}		
		scanner.close();
	}
}
