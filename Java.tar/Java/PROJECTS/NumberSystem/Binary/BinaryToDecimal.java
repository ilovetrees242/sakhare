import java.util.Scanner;

class main{
    public static void main(String [] args){

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your binary number: ");
        String BinaryDigits = scanner.nextLine();
        int Length = BinaryDigits.length();
        int Result = 0;

        for(int j = 0; j < Length; j++){
            if(BinaryDigits.charAt(j) != '0' && BinaryDigits.charAt(j) != '1'){
                System.out.println(j);
                System.out.println("ERROR! String contains a non binary character. Exiting... ");
                System.exit(1);
            }
        }
        for(int i = Length; i > 0; i--){
            if(BinaryDigits.charAt(i - 1) == '0'){
                Result += 0 * Math.pow(2, Length - i);
            }
            else if(BinaryDigits.charAt(i - 1) == '1'){
                Result += 1 * Math.pow(2, Length - i);
            }
        }
        System.out.println("Your result is: " + Result);
        scanner.close();
    }
}