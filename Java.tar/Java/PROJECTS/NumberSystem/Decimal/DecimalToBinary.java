import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter your decimal number(You can enter multiple decimal numbers seperated by spaces): ");
		String number = scanner.nextLine();
		
		String Number[] = number.split(" ");

		int Deci;
		String Binary = "";
		String BinaryTemp = "";
		String BinaryOutside = "";


		for(int i = 0; i < Number.length; i++){
			Deci = Integer.parseInt(Number[i]);
			while(Deci != 0){
				if(Deci % 2 == 1){
					Binary += "1";	
					Deci /= 2;
				}		
				else if(Deci % 2 == 0){
					Binary += "0";
					Deci /= 2;
				}
			}
			for(int j = Binary.length(); j > 0; j--){
				BinaryTemp += Character.toString(Binary.charAt(j - 1));
			}
			Binary = BinaryTemp;
			BinaryOutside = BinaryOutside + " " + Binary;
			Binary = "";
			BinaryTemp = "";
		}
		System.out.println("Your result is : " + BinaryOutside.trim());
		scanner.close();
	}
}
