import java.util.Scanner;
class Main{
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the decimal number to be converted to octal (spaces for multiple args): ");
        String Args = scanner.nextLine();
        String Numbers[] = Args.split(" ");

        int Deci;

        int remainder;
        String Temp = "";
        String Result = "";

        for(int i = 0; i < Numbers.length; i++){
            Deci = Integer.parseInt(Numbers[i]);
            while(Deci > 8){
                remainder = Deci % 8;
                if(remainder > 7){
                    Temp += (remainder + 3);
                }
                else{
                    Temp += remainder;
                }
                Deci /= 8;
                if(Deci < 8){
                    Temp += Deci;
                }
            }
            for(int j = Temp.length(); j > 0; j--){
                Result += Temp.charAt(j - 1);
            }
            Result += " ";
            Temp = "";
        }
        System.out.println(Args + " in octal: " + Result);
        scanner.close();
    }
}