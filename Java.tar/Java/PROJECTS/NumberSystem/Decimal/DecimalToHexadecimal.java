import java.util.Scanner;
class Main{
	public static void main(){
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the decimal number to be converted to hexadecimal(spaces for multiple args): ");
		String Numbers = scanner.nextLine();
		String Number[] = Numbers.split(" ");

		int Deci;

		String Result = "";
		String Temp = "";

		for(int i = 0; i < Number.length; i++){
			Deci = Integer.parseInt(Number[i]);
			if(16 < Deci){
				while(16 < Deci){
					Temp += Deci % 16;
					Deci /= 16;
					if(16 > Deci){
					Temp += Deci;
				}	
				System.out.println(Temp);	
			}
			else{
				if(Deci < 10){
					System.out.println(Deci);	
				}
				else{
					switch(Deci){
						case 1:
							System.out.println("A");
							break;	
						case 2:
							System.out.println("B");
							break;	
						case 3:
							System.out.println("C");
							break;	
						case 4:
							System.out.println("E");
							break;	
						case 5:
							System.out.println("D");
							break;	
						case 6:
							System.out.println("F");
							break;	
					}
				}
			}
		}

		scanner.close();
	}
}
