import java.util.Scanner;
class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the decimal number to be converted to hexadecimal(spaces for multiple args): ");
		String Numbers = scanner.nextLine();
		String Number[] = Numbers.split(" ");

		int Deci;
		String remainder = "";
		String Result = "";
		String Temp = "";
		String Answer;
		String FinalAnswer = "";

		for(int i = 0; i < Number.length; i++){
			Deci = Integer.parseInt(Number[i]);
			if(16 < Deci){
				while(16 < Deci){
					remainder += Deci % 16;
					switch(Integer.parseInt(remainder)){
						case 10: Temp += "A"; break;	
						case 11: Temp += "B"; break;	
						case 12: Temp += "C"; break;	
						case 13: Temp += "D"; break;	
						case 14: Temp += "E"; break;	
						case 15: Temp += "F"; break;
						default: Temp += remainder;
					}
					remainder = "";
					Deci /= 16;
					if(16 > Deci){
						switch(Deci){
							case 10: Temp += "A"; break;	
							case 11: Temp += "B"; break;	
							case 12: Temp += "C"; break;	
							case 13: Temp += "D"; break;	
							case 14: Temp += "E"; break;	
							case 15: Temp += "F"; break;
							default: Temp += Deci;
						}
					}
				}
				Result += Temp;		
			}	
			else{
				if(Deci < 10){
					System.out.println(Deci);	
				}
				else{
					switch(Deci){
						case 10: Temp += "A"; break;	
						case 11: Temp += "B"; break;	
						case 12: Temp += "C"; break;	
						case 13: Temp += "D"; break;	
						case 14: Temp += "E"; break;	
						case 15: Temp += "F"; break;
						default: Temp += Deci;
					}
				}
			}
			Answer = "";
			Result = Result.trim();
			for(int k = Result.length(); k > 0; k--){
				Answer += Character.toString(Result.charAt(k - 1));
			}
			FinalAnswer += Answer + " ";
			Result = "";
			Temp = "";
		}
		System.out.println("Your answer is: " + FinalAnswer.trim());
		scanner.close();
	}
}