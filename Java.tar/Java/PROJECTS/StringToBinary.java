import java.util.Scanner;
class Main{
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your text: ");
        String STR = scanner.nextLine();
        int remainder;
        int number;
        int limit = 0;
        char Ch;
        String Temp = "";
        String Temp2 = "";
        for(int j = 0; j < STR.length(); j++){
            Ch = STR.charAt(j);
            number = Ch;
            while(number != 0){
                remainder = number % 2;
                if(remainder == 0){
                    Temp += "0";
                    number /= 2;
                }
                else if(remainder == 1){
                    Temp += "1";
                    number /= 2;
                }
            }
            for(int i = Temp.length(); i > 0; i--){
                char ch = Temp.charAt(i - 1);
                Temp2 = Temp2 + ch;
            }
            System.out.print(Temp2 + " ");
            Temp2 = "";
            Temp = "";
            limit++;
            if(limit > 5){
                System.out.println();
                limit = 0;
            }
        }
        scanner.close();
    }
}