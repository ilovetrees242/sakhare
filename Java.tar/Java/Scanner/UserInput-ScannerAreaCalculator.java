import java.util.Scanner;

class Main{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the length: ");
		int A = scanner.nextInt();
		System.out.println("Enter the breadth: ");
		int B = scanner.nextInt();
		int area = A*B;
		System.out.println("The area is: "  + area);
	}
}
