import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("user input with boolean.");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Do you go to school? (true/false): ");
		boolean goToSchool = scanner.nextBoolean();
		System.out.println("You go to school: " + goToSchool);	
	}
}
