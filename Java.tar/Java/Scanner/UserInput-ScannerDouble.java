import java.util.Scanner;

class Main{
	public static void main(String[] args){
		System.out.println("User Input With Double Data Types");
		Scanner scanner = new Scanner(System.in);
		System.out.print("What is your GPA?: ");
		double gpa = scanner.nextDouble();
		System.out.println("Your GPA is " + gpa);
	}
}
