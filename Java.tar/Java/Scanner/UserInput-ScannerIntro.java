import java.util.Scanner;

class Main{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.print("enter your username: ");
		String userName = sc.nextLine();
		sc.close();
		System.out.println("hi " + userName);
	}
}
